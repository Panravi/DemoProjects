package com.telstra.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.telstra.model.NumberArrays;
import com.telstra.model.SingleArray;
import com.telstra.model.TriangleType;
import com.telstra.service.RestService;

@RestController
@RequestMapping("/api")
public class RestApiController {
	
	@Autowired
	private RestService restService;
	
	@RequestMapping(value = "/Fibonacci", method = RequestMethod.GET)
    public ResponseEntity<?> getFibonaciNumber(@RequestParam(name="n") Long number) {
		
		Integer nthFibonacinumber=restService.getFibonaciNumber(number);
		
        return new ResponseEntity<Integer>(nthFibonacinumber, HttpStatus.OK);
    }
	
	@RequestMapping(value = "/ReverseWords", method = RequestMethod.GET)
    public ResponseEntity<?> getReverseWords(@RequestParam String sentence) {
		
		String reverseWords=restService.getReverseWords(sentence);
		
        return new ResponseEntity<String>(reverseWords, HttpStatus.OK);
    }
	
	@RequestMapping(value = "/TriangleType", method = RequestMethod.GET)
    public ResponseEntity<?> getTraingleType(@RequestParam Integer a,@RequestParam Integer b,@RequestParam Integer c) {
		
		TriangleType triangleType=restService.getTraingleType(a, b, c);
		
        return new ResponseEntity<String>(triangleType.getTriangleType(), HttpStatus.OK);
    }
	
	@RequestMapping(value = "/makeonearray", method = RequestMethod.POST)
    public ResponseEntity<?> makeOneArray(@RequestBody NumberArrays numberArrs) {
		
		SingleArray singleArray=restService.makeOneArray(numberArrs);
		
        return new ResponseEntity<SingleArray>(singleArray, HttpStatus.OK);
    }
	

}
