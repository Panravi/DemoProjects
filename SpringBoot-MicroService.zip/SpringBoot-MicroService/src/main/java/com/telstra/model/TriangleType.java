package com.telstra.model;

public class TriangleType {
	
	private String triangleType;

	/**
	 * @return the triangleType
	 */
	public String getTriangleType() {
		return triangleType;
	}

	/**
	 * @param triangleType the triangleType to set
	 */
	public void setTriangleType(String triangleType) {
		this.triangleType = triangleType;
	}

   
}
