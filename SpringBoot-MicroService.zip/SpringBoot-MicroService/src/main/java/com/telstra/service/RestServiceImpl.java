package com.telstra.service;

import java.util.Set;
import java.util.TreeSet;

import org.springframework.stereotype.Component;

import com.telstra.model.NumberArrays;
import com.telstra.model.SingleArray;
import com.telstra.model.TriangleType;

@Component
public class RestServiceImpl implements RestService{
	
	public enum TRIANGLE {
        EQUILATERAL, ISOSCELES, SCALENE,NOTATRIANGLE
    }
	
	@Override
	public Integer getFibonaciNumber(Long number) {
		int a = 0;
		int b = 1;

		for (int i = 2; i <= number; i++) {
			int temp = a;
			a = a + b;
			b = temp;
		}
		return a;
	}	
	
	@Override
	public String getReverseWords(String sentence) {
		String[] words = sentence.split(" ");
		
		String reverseString = "";
		
		for (int i = 0; i < words.length; i++) 
		{
			String word = words[i];
			
			String reverseWord = "";
			
			for (int j = word.length()-1; j >= 0; j--) 
			{
				reverseWord = reverseWord + word.charAt(j);
			}
			
			reverseString = reverseString + reverseWord + " ";
		}
		return reverseString;
	}

	@Override
	public TriangleType getTraingleType(Integer a,Integer b,Integer c)
	{
		TriangleType triangleType=new TriangleType();
		
		if(a==b && b==c){
			triangleType.setTriangleType(TRIANGLE.EQUILATERAL.name());
			return triangleType;
		}

        else if ((a==b && b!=c ) || (a!=b && c==a) || (c==b && c!=a))
        {
        	triangleType.setTriangleType(TRIANGLE.ISOSCELES.name());
			return triangleType;
        }

        else if(a!=b && b!=c && c!=a)
        {
        	triangleType.setTriangleType(TRIANGLE.SCALENE.name());
			return triangleType;
        }
        else
        {
        	triangleType.setTriangleType(TRIANGLE.NOTATRIANGLE.name());
			return triangleType;
        }
         
	}

	@Override
	public SingleArray makeOneArray(NumberArrays numberArrs)
	{
		Integer[] Array1=numberArrs.getArray1();
		Integer[] Array2=numberArrs.getArray2();
		Integer[] Array3=numberArrs.getArray3();
		
		Set<Integer> arrayList=new TreeSet<>();
		
		for(int i=0;i<Array1.length;i++)
		{
			arrayList.add(Array1[i]);
		}
		
		for(int i=0;i<Array2.length;i++)
		{
			arrayList.add(Array2[i]);
		}
		
		for(int i=0;i<Array3.length;i++)
		{
			arrayList.add(Array3[i]);
		}
		
		SingleArray singleArray=new SingleArray();
		singleArray.setArray(arrayList.toArray());
		
		return singleArray;
	}

}
